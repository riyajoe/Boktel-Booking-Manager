from django.contrib import admin
from PYB_103app.models import Student,Employee

# Register your models here.
admin.site.register(Student)
admin.site.register(Employee)