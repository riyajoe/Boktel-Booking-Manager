from django.apps import AppConfig


class Pyb103AppConfig(AppConfig):
    name = 'PYB_103app'
