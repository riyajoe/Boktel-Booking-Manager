from django.db import models

# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(unique=True)
    active=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now=True)
    last_logged_in=models.DateTimeField(auto_now=True)
    def __str__(self):
        return 'Student(name='+self.name+',email='+str(self.email)+')\n'   
class Employee(models.Model):
    eid=models.IntegerField()
    name=models.CharField(max_length=30)
    age=models.IntegerField()
    address=models.CharField(max_length=100)   
    created_on=models.DateTimeField(auto_now=True)