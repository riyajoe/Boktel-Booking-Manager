from django.shortcuts import render

from django.views.generic import TemplateView,CreateView
from .forms import Empform



class HomePage(TemplateView):
    template_name='Home.html'
class EmployeeReg(CreateView):
    template_name='Emp.html'
    form_class=Empform
    success_url='sucessful'   
