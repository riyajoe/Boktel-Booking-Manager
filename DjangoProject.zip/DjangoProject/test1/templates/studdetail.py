from django.urls import path
from test1app.views import Hello,FirstPage,Addstudent,Liststudents,StudentUpdate,Studentdetail

urlpatterns = [
path('hello',Hello.as_view()),
path('FirstPage',FirstPage.as_view()),
path('add',Addstudent.as_view()),
path('list',Liststudents.as_view()),
path('edit/(?p<pk>[0-9]+)',StudentUpdate.as_view(),name='edit'),
path('Studentdetail/(?p<pk>[0-9]+)',Studentdetail.as_view(),name='Studentdetail')
]