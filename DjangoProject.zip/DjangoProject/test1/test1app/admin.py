from django.contrib import admin
from test1app.models import Author,Student

# Register your models here.
admin.site.register(Author)
admin.site.register(Student)

