from django.apps import AppConfig


class Test1AppConfig(AppConfig):
    name = 'test1app'
