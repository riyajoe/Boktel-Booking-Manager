from django.shortcuts import render
from django.views.generic import TemplateView,CreateView,ListView,UpdateView,DetailView
from .forms import Studentform
from .models import Student 
from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger
# Create your views here.


class Hello(TemplateView):
    template_name='Hello.html'
class FirstPage(TemplateView):
    template_name="Page1.html"
class Addstudent(CreateView):
    template_name='Student.html'
    form_class=Studentform
    success_url='sucessful'
class Liststudents(ListView):
    template_name='studentlist.html'
    model=Student
    queryset=Student.objects.all()
    #queryset=Student.objects.filter(name__contains='a')
    context_object_name='student_list' #object_list is reffered here 
    ordering=['-name'] #ascending and descending '-'
    paginate_by=3
class StudentUpdate(UpdateView):
    template_name='student.html'
    model=Student
    fields=['name','age'] #update able fields 
    success_url='success'
class Studentdetail(DetailView):
    model=Student
    template_name='studdetail.html'