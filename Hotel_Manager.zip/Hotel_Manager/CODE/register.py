#!/usr/bin/python3

import cgi
import cgitb
import hashlib, binascii, os
import datetime

cgitb.enable()
from jinja2 import Template, Environment, FileSystemLoader

import os, sys
import imp

import constants
from authorizenet import apicontractsv1
from authorizenet.apicontrollers import *

constants = imp.load_source('modulename', 'constants.py')
import random

print("Content-type: text/html")
print()
print("<br>")
# Create instance of FieldStorage
form_data = cgi.FieldStorage()

# Get data from fields

User_Name=str(form_data["User_Id"].value)
First_Name = str(form_data["FNAME"].value)
Second_Name= str(form_data["SNAME"].value)
Gender = str(form_data["gender"].value)
DOB=str(form_data["DOB"].value)
Address = str(form_data["Address"].value)
Aadhar_No= str(form_data["AD"].value)
Contact_No = str(form_data["Phno"].value)
Email = str(form_data["email"].value)
Password = str(form_data["pass"].value)
 


import pymysql
from pymysql.err import MySQLError


def hash_password(password):
    salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
    pwdhash = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), salt, 100000)
    pwdhash = binascii.hexlify(pwdhash)
    return (salt + pwdhash).decode('ascii')


new_password = hash_password(Password)
salt = new_password[:64]

merchantAuth = apicontractsv1.merchantAuthenticationType()
merchantAuth.name = constants.apiLoginId
merchantAuth.transactionKey = constants.transactionKey

createCustomerProfile = apicontractsv1.createCustomerProfileRequest()
createCustomerProfile.merchantAuthentication = merchantAuth
createCustomerProfile.profile = apicontractsv1.customerProfileType(User_Name, First_Name, Email)

controller = createCustomerProfileController(createCustomerProfile)
controller.execute()

response = controller.getresponse()

customer_profile_id = response.customerProfileId
print(customer_profile_id)

current_time = str(datetime.datetime.now())

'''
conn = pymysql.connect(
    db='pyb103',
    user='pyb103',
    passwd='ZRYlxNXat',
    host='localhost')
c = conn.cursor()

try:

    sql = 'INSERT INTO User_Reg(User_Name,First_Name,Second_Name,Gender,DOB,Address,Aadhar_No,Contact_No,Salt_Value,Created_On,Password,Email) VALUES("%s", "%s", "%s","%s","%s","%s","%s","%s","%s","%s","%s","%s")' % (User_Name,First_Name,Second_Name,Gender,DOB,Address,Aadhar_No,Contact_No,salt,current_time,new_password,Email)
    print(sql)
    c.execute(sql)
    conn.commit()
    
    sql2='select User_Id from User_Reg where User_Name="%s"'%(User_Name)
    print(sql2)
    c.execute(sql2)
    row=c.fetchone()
    customer_id=row[0]
    print(customer_id)
    conn.commit()

    sql1 = 'INSERT INTO Payment_Ref(Customer_Profile_Id,User_Id) VALUES ("%s","%s")' % (customer_profile_id,customer_id)
    print(sql1)
    c.execute(sql1)
    conn.commit()

except MySQLError as e:
    print('Got error {!r}, errno is {}'.format(e, e.args[0]))
'''
env = Environment(loader=FileSystemLoader('templates'))
template = env.get_template('output.html')
output_from_parsed_template = template.render(id=customer_profile_id)

try:
   fh = open("output.html", "w")
   fh.write("please save your customer_profile_id ::")
   fh.write(output_from_parsed_template)
   '''fh.write(str(User_Name))
   fh.write(str(First_Name))
   fh.write(str(Second_Name))
   fh.write(str(Gender))
   fh.write(str(DOB))
   fh.write(str(Address))
   fh.write(str(Aadhar_No))
   fh.write(str(Contact_No))
   fh.write(str(salt))
   fh.write(str(current_time))
   fh.write(str(new_password))
   fh.write(str(Email))'''

except IOError:
   print("<br>Error: can't find file or read data")
else:
   print ("Written content in the file successfully")
   pass
print("Content-type:text/html\n\n")
redirectURL = "  http://pyb103.specind.net/output.html"
print("<html>")
print("<head>")
print('<meta http-equiv="refresh" content="0;url=' + str(redirectURL) + '" />')
print("</head>")
print("</html>")




