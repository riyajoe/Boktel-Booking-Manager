from django.contrib import admin
from PY103app.models import Student

# Register your models here.
admin.site.register(Student)
