from django.apps import AppConfig


class Py103AppConfig(AppConfig):
    name = 'PY103app'
