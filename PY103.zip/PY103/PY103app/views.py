from django.shortcuts import render
from django.views.generic import TemplateView,CreateView,ListView
from .forms import Studform

# Create your views here.
class Home(TemplateView):
    template_name='Home.html'
class Addstud(CreateView):
    template_name='Add.html'
    form_class='Studform'
    success_url='sucess'